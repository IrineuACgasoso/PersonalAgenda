// src/hooks/usePersistedData.js
import { useState, useEffect, useRef } from "react";
import { doc, onSnapshot, setDoc } from "firebase/firestore";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { db, auth, loginComGoogle, fazerLogout, EMAIL_PERMITIDO } from "../firebase";
import { STORAGE_KEY } from "../constants";

const DADOS_PADRAO = {
  periodos: [{ id: "p1", nome: "2026.1" }],
  cadeiras: [],
  compromissos: [],
  afazeres: [],
  eventosConcluidos: [],
  periodoAtivoId: "p1",
};

function sanitizarDados(raw) {
  if (!raw || typeof raw !== "object") return DADOS_PADRAO;

  return {
    ...DADOS_PADRAO,
    ...raw,
    periodos: Array.isArray(raw.periodos) && raw.periodos.length > 0 ? raw.periodos : DADOS_PADRAO.periodos,
    cadeiras: Array.isArray(raw.cadeiras) ? raw.cadeiras : [],
    compromissos: Array.isArray(raw.compromissos) ? raw.compromissos : [],
    eventosConcluidos: Array.isArray(raw.eventosConcluidos) ? raw.eventosConcluidos : [],
    afazeres: Array.isArray(raw.afazeres)
      ? raw.afazeres.map((a) => ({
          ...a,
          feito: !!a.feito,
          datasConcluidas: Array.isArray(a.datasConcluidas) ? a.datasConcluidas : [],
          rotina: {
            tipo: a.rotina?.tipo || "nenhuma",
            intervaloDias: a.rotina?.intervaloDias || 1,
            totalRepeticoes: a.rotina?.totalRepeticoes || "",
          },
        }))
      : [],
  };
}

export default function usePersistedData() {
  const [user, setUser] = useState(null);
  const [data, setData] = useState(null);
  const [status, setStatus] = useState("loading");
  const carregadoRef = useRef(false);

  // 1. Escuta Autenticação
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        if (currentUser.email !== EMAIL_PERMITIDO) {
          await signOut(auth);
          setUser(null);
          return;
        }
        setUser(currentUser);
      } else {
        setUser(null);
        const local = localStorage.getItem(STORAGE_KEY);
        const parsed = local ? JSON.parse(local) : DADOS_PADRAO;
        setData(sanitizarDados(parsed));
        carregadoRef.current = true;
        setStatus("saved");
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // 2. Escuta Firestore com trava de segurança no carregamento inicial
  useEffect(() => {
    if (!user) return;

    setStatus("loading");
    carregadoRef.current = false;
    const userDocRef = doc(db, "users", user.uid);

    const unsubscribeSnapshot = onSnapshot(
      userDocRef,
      async (docSnap) => {
        if (docSnap.exists()) {
          setData(sanitizarDados(docSnap.data()));
        } else {
          // Só cria documento padrão se realmente não existir nada no banco
          const localDataRaw = localStorage.getItem(STORAGE_KEY);
          const dataInicial = localDataRaw ? JSON.parse(localDataRaw) : DADOS_PADRAO;
          const dataSanitizada = sanitizarDados(dataInicial);
          await setDoc(userDocRef, dataSanitizada);
          setData(dataSanitizada);
        }
        carregadoRef.current = true;
        setStatus("saved");
      },
      (error) => {
        console.error("Erro no Firestore:", error);
        setStatus("error");
      }
    );

    return () => unsubscribeSnapshot();
  }, [user]);

  // 3. Persistência segura (bloqueia salvar enquanto não tiver certeza do carregamento)
  const persist = async (newData) => {
    if (!carregadoRef.current) {
      console.warn("Tentativa de salvar bloqueada: dados ainda estão sendo carregados do banco.");
      return;
    }

    const dataSanitizada = sanitizarDados(newData);
    setData(dataSanitizada);
    setStatus("saving");

    try {
      if (user) {
        const userDocRef = doc(db, "users", user.uid);
        await setDoc(userDocRef, dataSanitizada);
      } else {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(dataSanitizada));
      }
      setStatus("saved");
    } catch (err) {
      console.error("Erro ao salvar dados:", err);
      setStatus("error");
    }
  };

  return {
    data,
    persist,
    status,
    user,
    loginWithGoogle: loginComGoogle,
    logout: fazerLogout,
  };
}