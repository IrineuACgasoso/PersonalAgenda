// src/utils/sanitizarDados.js

export function sanitizarDados(dados) {
  if (!dados || typeof dados !== "object") return dados;

  return {
    ...dados,
    periodos: Array.isArray(dados.periodos) ? dados.periodos : [],
    cadeiras: Array.isArray(dados.cadeiras) ? dados.cadeiras : [],
    compromissos: Array.isArray(dados.compromissos) ? dados.compromissos : [],
    eventosConcluidos: Array.isArray(dados.eventosConcluidos) ? dados.eventosConcluidos : [],
    afazeres: Array.isArray(dados.afazeres)
      ? dados.afazeres.map((afazer) => ({
          ...afazer,
          feito: !!afazer.feito,
          datasConcluidas: Array.isArray(afazer.datasConcluidas) ? afazer.datasConcluidas : [],
          rotina: {
            tipo: afazer.rotina?.tipo || "nenhuma",
            intervaloDias: afazer.rotina?.intervaloDias || 1,
            totalRepeticoes: afazer.rotina?.totalRepeticoes || "",
          },
        }))
      : [],
  };
}