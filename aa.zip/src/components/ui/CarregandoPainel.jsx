// src/components/ui/CarregandoPainel.jsx
import React from "react";

/**
 * Tela de "boot" exibida por um instante toda vez que um painel lateral
 * (Cadeira ou Compromisso) é aberto — antes de mostrar o conteúdo real.
 * O vídeo (`/loading-painel.mp4`) é um loop boomerang (vai e volta, sem
 * áudio) pré-renderizado e cacheado pelo service worker do PWA, então
 * funciona offline igual ao resto do app.
 */
export default function CarregandoPainel() {
  return (
    <div className="painel-carregando">
      <video
        className="painel-carregando-video"
        src="/loading-painel.mp4"
        autoPlay
        loop
        muted
        playsInline
      />
      <span className="painel-carregando-texto">Carregando painel...</span>
    </div>
  );
}